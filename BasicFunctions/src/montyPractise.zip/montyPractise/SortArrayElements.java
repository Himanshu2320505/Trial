package montyPractise;

public class SortArrayElements {

	public static void main(String[] args) {
		String[] s = {"amal","monty","kela","rahul"};
		for(int i=0;i<s.length;i++) {
			
			System.out.println(s[i]);
		String y = s[i];
			for(int j=0;j<s[i].length();j++) {
				for(int k=0,x;k<s[i].length();k++) {
				//	if(y.charAt(k).compareTo(y.charAt(k+1))==1) {
						
				//	}
				}
				
			}
		}

	}

}
