package montyPractise;

public class PrimeInput {
	
	

}
